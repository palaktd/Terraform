<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.1.9 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 3.28.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 3.28.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_network_interface.nic](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface_security_group_association.example](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_network_security_group.nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_public_ip.public_ip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_windows_virtual_machine.main](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/windows_virtual_machine) | resource |
| [random_string.computer_name](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |
| [azurerm_shared_image_version.image](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/shared_image_version) | data source |
| [azurerm_subnet.subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subnet) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_admin_password"></a> [admin\_password](#input\_admin\_password) | (Required) Password of the vm | `string` | n/a | yes |
| <a name="input_admin_username"></a> [admin\_username](#input\_admin\_username) | (Required) Username of the vm | `string` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | name tag for the environment | `string` | n/a | yes |
| <a name="input_image_parameters"></a> [image\_parameters](#input\_image\_parameters) | (required) image details for the VM creation | <pre>object({<br>    gallery_name = string<br>    image_name = string<br>    image_version   = string<br>    resource_group_name = string<br>  })</pre> | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Optional) region | `string` | n/a | yes |
| <a name="input_nsg_parameters"></a> [nsg\_parameters](#input\_nsg\_parameters) | n/a | <pre>object({<br>    enable_nsg = bool   # whether nsg required for the vm<br>    nsg_name   = string # provide the value of exisitng/new nsg name<br>    security_rules = list(object({<br>      name                       = string<br>      priority                   = number<br>      direction                  = string<br>      access                     = string<br>      protocol                   = string<br>      source_port_range          = string<br>      destination_port_range     = string<br>      source_address_prefix      = string<br>      destination_address_prefix = string<br>    }))<br>  })</pre> | n/a | yes |
| <a name="input_os_disk_parameters"></a> [os\_disk\_parameters](#input\_os\_disk\_parameters) | (required) os disk details for the VM creation | <pre>object({<br>    name    = string # name of the os disk<br>    caching = string # caching of the os disk<br>    type    = string # os disk type<br>  })</pre> | n/a | yes |
| <a name="input_private_ip_allocation"></a> [private\_ip\_allocation](#input\_private\_ip\_allocation) | (Required) The allocation method for IP. Possible values are Dynamic and Static | `string` | n/a | yes |
| <a name="input_public_ip_parameters"></a> [public\_ip\_parameters](#input\_public\_ip\_parameters) | n/a | <pre>object({<br>    enable_public_ip  = bool<br>    allocation_method = string # ip allocation method static or dynamic<br>    ip_version        = string # Ip version. either IPv4 or IPv6<br>  })</pre> | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | Name of the resource group for the Virtual Machine | `string` | n/a | yes |
| <a name="input_subnet_name"></a> [subnet\_name](#input\_subnet\_name) | (Required) The name of the subnet | `string` | n/a | yes |
| <a name="input_virtual_machine_name"></a> [virtual\_machine\_name](#input\_virtual\_machine\_name) | Name of the Virtual Machine | `string` | n/a | yes |
| <a name="input_vm_size"></a> [vm\_size](#input\_vm\_size) | (Required) The size of Virtual Machine | `string` | n/a | yes |
| <a name="input_vnet_name"></a> [vnet\_name](#input\_vnet\_name) | (Required) The name of the virtual network | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_virtual_machine_id"></a> [virtual\_machine\_id](#output\_virtual\_machine\_id) | The id of the bastion Host |
<!-- END_TF_DOCS -->