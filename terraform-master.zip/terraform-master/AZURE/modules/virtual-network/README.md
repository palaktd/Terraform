<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.1.9 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 3.28.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 3.28.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_nat_gateway.nat](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/nat_gateway) | resource |
| [azurerm_nat_gateway_public_ip_association.nat_pip_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/nat_gateway_public_ip_association) | resource |
| [azurerm_network_security_group.nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_public_ip.nat_pip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_route_table.route_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_subnet.subnets](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_nat_gateway_association.nat_subnet_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_nat_gateway_association) | resource |
| [azurerm_subnet_network_security_group_association.example](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.azurerm_subnet_route_table_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_virtual_network.vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |
| [azurerm_subnet.nat_subnets](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subnet) | data source |
| [azurerm_subnet.nsg_subnets](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subnet) | data source |
| [azurerm_subnet.route_table_subnets](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subnet) | data source |
| [azurerm_virtual_network.vnet_data](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/virtual_network) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_address_space"></a> [address\_space](#input\_address\_space) | address space required for the virtual network | `string` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | name tag for the environment | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | location for the resources | `string` | n/a | yes |
| <a name="input_nat_name"></a> [nat\_name](#input\_nat\_name) | name of the nat gateway | `string` | n/a | yes |
| <a name="input_nsg_name"></a> [nsg\_name](#input\_nsg\_name) | name of the network security group | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | name of an virtual network resource group | `string` | n/a | yes |
| <a name="input_route_table_parameters"></a> [route\_table\_parameters](#input\_route\_table\_parameters) | n/a | <pre>object({<br>    name = string<br>    disable_bgp_route_propagation = bool<br>    routes = list(object({<br>      name = string<br>      address_prefix = string<br>      next_hop_type = string<br>      next_hop_in_ip_address = string<br>    }))<br>  })</pre> | n/a | yes |
| <a name="input_security_rules"></a> [security\_rules](#input\_security\_rules) | n/a | <pre>list(object({<br>    name                       = string<br>    priority                   = number<br>    direction                  = string<br>    access                     = string<br>    protocol                   = string<br>    source_port_range          = string<br>    destination_port_range     = string<br>    source_address_prefix      = string<br>    destination_address_prefix = string<br>  }))</pre> | n/a | yes |
| <a name="input_subnets"></a> [subnets](#input\_subnets) | subnets to be created along with the virtual network | <pre>list(object({<br>    subnet_name  =  string<br>    subnet_cidr_range = list(string)<br>    route_table_subnet_association =bool<br>    nat_subnet_association = bool<br>    nsg_subnet_association = bool}<br>  ))</pre> | n/a | yes |
| <a name="input_vnet_name"></a> [vnet\_name](#input\_vnet\_name) | name of the virtual network | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_nat_id"></a> [nat\_id](#output\_nat\_id) | id of the nat gateway |
| <a name="output_nat_name"></a> [nat\_name](#output\_nat\_name) | name of the nat gateway |
| <a name="output_nsg_id"></a> [nsg\_id](#output\_nsg\_id) | id of the network security group |
| <a name="output_nsg_name"></a> [nsg\_name](#output\_nsg\_name) | name of the network security groups |
| <a name="output_subnets"></a> [subnets](#output\_subnets) | ids of the subnets created |
| <a name="output_vnet_id"></a> [vnet\_id](#output\_vnet\_id) | vnet id of the created virtual network |
| <a name="output_vnet_name"></a> [vnet\_name](#output\_vnet\_name) | name of the created virtual network |
<!-- END_TF_DOCS -->