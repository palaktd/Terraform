<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.1.9 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 3.28.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 3.28.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_bastion_host.bastion_host](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/bastion_host) | resource |
| [azurerm_public_ip.bastion_pip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_subnet.bastion_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subnet) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_bastion_host_name"></a> [bastion\_host\_name](#input\_bastion\_host\_name) | name of the Bastion Host | `string` | n/a | yes |
| <a name="input_bastion_optional_parameters"></a> [bastion\_optional\_parameters](#input\_bastion\_optional\_parameters) | n/a | <pre>object({<br>    copy_paste_enabled  = optional(bool, true)<br>    ip_connect_enabled = optional(bool, false)<br>    scale_units = optional(number, 2)<br>    shareable_link_enabled = optional(bool, false)<br>    tunneling_enabled = optional(bool, false)<br>  })</pre> | n/a | yes |
| <a name="input_bastion_sku"></a> [bastion\_sku](#input\_bastion\_sku) | sku of the bastion host. must be one of basic or standard | `string` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | Name of the Environment | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | Region of the bastion host and bastion public ip | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | name of the virtual network resource group and bastion host resource group | `string` | n/a | yes |
| <a name="input_vnet_name"></a> [vnet\_name](#input\_vnet\_name) | virtual nework where bastion host needs to be deployed | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_bastion_host_id"></a> [bastion\_host\_id](#output\_bastion\_host\_id) | resource id of the bastion host |
| <a name="output_vnet_name"></a> [vnet\_name](#output\_vnet\_name) | name of the virtual network |
<!-- END_TF_DOCS -->