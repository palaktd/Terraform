<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.1.9 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 3.28.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 3.28.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_storage_account.storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_container.containers](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |
| [azurerm_storage_share.file_share](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_share) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_account_kind"></a> [account\_kind](#input\_account\_kind) | The Account Kind for the Storage Account(Optional) | `string` | n/a | yes |
| <a name="input_account_replication_type"></a> [account\_replication\_type](#input\_account\_replication\_type) | The Replication type for the Storage account(Required) | `string` | n/a | yes |
| <a name="input_account_tier"></a> [account\_tier](#input\_account\_tier) | The account tier for the storage account(Required) | `string` | n/a | yes |
| <a name="input_blob_storage"></a> [blob\_storage](#input\_blob\_storage) | n/a | <pre>object({<br>    access_tier                       = string<br>    cross_tenant_replication_enabled  = optional(bool, "true")<br>  })</pre> | n/a | yes |
| <a name="input_container_names"></a> [container\_names](#input\_container\_names) | list of containers to be created along with the Storage account | `list(string)` | n/a | yes |
| <a name="input_fileshare_names"></a> [fileshare\_names](#input\_fileshare\_names) | list of fileshare to be created along with the storage account | `list(string)` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | Location where storage account needs to be created(Required) | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | Resource group for the Storage Account(Required) | `string` | n/a | yes |
| <a name="input_storage_account_name"></a> [storage\_account\_name](#input\_storage\_account\_name) | Name of the Storage account(Required) | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_storage_account_id"></a> [storage\_account\_id](#output\_storage\_account\_id) | id of the Storage account |
| <a name="output_storage_account_name"></a> [storage\_account\_name](#output\_storage\_account\_name) | name of the storage account |
<!-- END_TF_DOCS -->