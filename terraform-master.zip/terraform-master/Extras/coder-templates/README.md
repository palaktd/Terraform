# Coder Template Creation

# Context
```
Coder Templates are written in standard Terraform and describe the infrastructure for workspaces.
Create a template for developers to create workspaces.
```

# Structure
```
└──Template(Template name ex: AWS-Windows-Machine-Tmpl-V1, Azure-Linux-Machine-Tmpl-V1)
│   └──main.tf
│   └──cloud-config.yaml.tftpl (This is only for Azure linux template)
└──Template2
│   └──main.tf
└──Template3
│   └──main.tf
```
# Templates can be created in two ways:

# 1. Using Coder GUI
```
Signin to Coder using OpenID Connect after accessing this link: https://cdw.app.corpintra.net/

Provide who is who credentials to signin.

Redirect to Templates page and select "+ Add template" and provide necessary details to add your template. 
or select "Starter templates" and choose existing templates and make changes as per your requirement.
```
# 2. Using Coder CLI
```
echo "###################################"
echo "Installing Coder CLI and terraform"
echo "###################################"
Reference link to install Coder CLI: https://coder.com/docs/v2/latest/install
Reference link to install terraform: https://developer.hashicorp.com/terraform/downloads 
				 and https://stackoverflow.com/questions/1618280/where-can-i-set-path-to-make-exe-on-windows

echo "##############################################################################"
echo "Open CLI and login to Coder by executing below command and follow the process."
echo "##############################################################################"
coder login https://cdw.app.corpintra.net/   #Provide your coder application URL

echo "####################################################################"
echo "Create a template from the current directory or as specified by flag"
echo "####################################################################"
coder templates create <template name> 

echo "###################################################"
echo "Download the latest version of a template to a path"
echo "###################################################"
coder templates pull <template name>

echo "##############################################################################"
echo "Push a new template version from the current directory or as specified by flag"
echo "##############################################################################"
coder templates push <template name>
```

