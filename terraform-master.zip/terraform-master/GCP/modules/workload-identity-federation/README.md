<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google_iam_workload_identity_pool.aws-pool](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/iam_workload_identity_pool) | resource |
| [google_iam_workload_identity_pool_provider.aws-provider](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/iam_workload_identity_pool_provider) | resource |
| [google_service_account_iam_binding.grant_access](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/service_account_iam_binding) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aws_account_id"></a> [aws\_account\_id](#input\_aws\_account\_id) | AWS Project ID | `number` | n/a | yes |
| <a name="input_aws_iam_role"></a> [aws\_iam\_role](#input\_aws\_iam\_role) | AWS IAM role which tagged to EC2 Instances | `string` | n/a | yes |
| <a name="input_gcp_project_no"></a> [gcp\_project\_no](#input\_gcp\_project\_no) | GCP Project NO. | `number` | n/a | yes |
| <a name="input_namespace"></a> [namespace](#input\_namespace) | Project namespace | `string` | n/a | yes |
| <a name="input_pool_id"></a> [pool\_id](#input\_pool\_id) | workload identity pool id | `string` | n/a | yes |
| <a name="input_project"></a> [project](#input\_project) | Project ID/Name | `string` | n/a | yes |
| <a name="input_provider_id"></a> [provider\_id](#input\_provider\_id) | workload identity pool provider id | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | Project region | `string` | n/a | yes |
| <a name="input_service_account"></a> [service\_account](#input\_service\_account) | Service Account to access resources | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_gcp_workload_identity_pool"></a> [gcp\_workload\_identity\_pool](#output\_gcp\_workload\_identity\_pool) | work load identity pool |
| <a name="output_gcp_workload_identity_provider"></a> [gcp\_workload\_identity\_provider](#output\_gcp\_workload\_identity\_provider) | work load identity provider |
<!-- END_TF_DOCS -->