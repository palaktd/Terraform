<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google_compute_network_peering.peering-cdw-prod-global-nicedcv](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_network_peering) | resource |
| [google_compute_network_peering.peering-nicedcv-cdw-prod-global](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_network_peering) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_connection"></a> [connection](#input\_connection) | The VPC peering connection resource | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | environment | `string` | n/a | yes |
| <a name="input_local_network"></a> [local\_network](#input\_local\_network) | Resource link of the network to add a peering to | `string` | n/a | yes |
| <a name="input_namespace"></a> [namespace](#input\_namespace) | Project namespace | `string` | n/a | yes |
| <a name="input_peer_network"></a> [peer\_network](#input\_peer\_network) | Resource link of the peer network. | `string` | `""` | no |
| <a name="input_project"></a> [project](#input\_project) | Project ID/Name | `string` | n/a | yes |
| <a name="input_usecase"></a> [usecase](#input\_usecase) | The usecase of the VPC | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_network_peering_info_global_nicedcv"></a> [network\_peering\_info\_global\_nicedcv](#output\_network\_peering\_info\_global\_nicedcv) | Network peering information from global vpc to nicedcv vpc |
| <a name="output_network_peering_info_nicedcv_global"></a> [network\_peering\_info\_nicedcv\_global](#output\_network\_peering\_info\_nicedcv\_global) | Network peering information from gloabl vpc to nicedcv vpc |
<!-- END_TF_DOCS -->