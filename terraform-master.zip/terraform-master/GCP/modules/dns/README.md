<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_gcs_label"></a> [gcs\_label](#module\_gcs\_label) | ../tf-gcp-label | n/a |

## Resources

| Name | Type |
|------|------|
| [google_storage_bucket.bucket_backend](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_bucket) | resource |
| [google_storage_bucket_iam_binding.bucket_be_binding](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_bucket_iam_binding) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_LifecyclePolicyRequired"></a> [LifecyclePolicyRequired](#input\_LifecyclePolicyRequired) | Determine if the bucket should be required the lifecycle policy, when setting true need to fill the var.lifecycle\_rules | `bool` | `null` | no |
| <a name="input_bucket"></a> [bucket](#input\_bucket) | Bucket Details | <pre>object({<br>    bucket_purpose     = string,<br>    location           = string,<br>    storage_class      = string,<br>    bucket_policy_only = bool,<br>    force_destroy      = bool,<br>    #kms_key_name           = string,<br>    retention_policy_rules = list(map(string)),<br>    #lifecycle_rules= list(object({action = any,condition = any})),<br>    iam_binding = list(object({ role = string, members = list(string) }))<br>  })</pre> | n/a | yes |
| <a name="input_compact_project_name"></a> [compact\_project\_name](#input\_compact\_project\_name) | Compact project name | `string` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | enviroment | `string` | n/a | yes |
| <a name="input_labels"></a> [labels](#input\_labels) | Labels for resource | `map(any)` | n/a | yes |
| <a name="input_lifecycle_rules"></a> [lifecycle\_rules](#input\_lifecycle\_rules) | The bucket's Lifecycle Rules configuration. | <pre>list(object({<br>    action = any<br><br>    condition = any<br>  }))</pre> | <pre>[<br>  {<br>    "action": {<br>      "type": "Delete"<br>    },<br>    "condition": {<br>      "age": 90<br>    }<br>  }<br>]</pre> | no |
| <a name="input_namespace"></a> [namespace](#input\_namespace) | Project namespace | `string` | n/a | yes |
| <a name="input_project"></a> [project](#input\_project) | Project ID/Name | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | Project region | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_bucket"></a> [bucket](#output\_bucket) | The created storage bucket |
| <a name="output_gcs_bucket_name"></a> [gcs\_bucket\_name](#output\_gcs\_bucket\_name) | gcs bucket name |
<!-- END_TF_DOCS -->