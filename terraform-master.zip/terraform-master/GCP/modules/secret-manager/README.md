<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google_secret_manager_secret.my-secret](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/secret_manager_secret) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_environment"></a> [environment](#input\_environment) | Environment of the secret-manager | `string` | n/a | yes |
| <a name="input_labels"></a> [labels](#input\_labels) | Labels for the secret | `map(string)` | n/a | yes |
| <a name="input_namespace"></a> [namespace](#input\_namespace) | the namespace for the secret-manager | `string` | n/a | yes |
| <a name="input_project"></a> [project](#input\_project) | Project ID/Name | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | The region for the user-managed replica | `string` | n/a | yes |
| <a name="input_secrets"></a> [secrets](#input\_secrets) | A map of secret names to secret data | <pre>map(object({<br>    value       = string<br>    description = string<br>  }))</pre> | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_secret_name"></a> [secret\_name](#output\_secret\_name) | The name of the created secret |
<!-- END_TF_DOCS -->