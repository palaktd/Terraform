<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google_compute_address.endpoint](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_address) | resource |
| [google_compute_forwarding_rule.forwarding_rule_dns](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_forwarding_rule) | resource |
| [google_compute_region_backend_service.backend_service](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_region_backend_service) | resource |
| [google_compute_region_network_endpoint_group.service_attachment](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_region_network_endpoint_group) | resource |
| [google_compute_region_target_tcp_proxy.targetTcpProxies](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_region_target_tcp_proxy) | resource |
| [google_dns_response_policy.response-policy](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/dns_response_policy) | resource |
| [google_dns_response_policy_rule.response-policy-rule](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/dns_response_policy_rule) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_environment"></a> [environment](#input\_environment) | environment | `string` | n/a | yes |
| <a name="input_labels"></a> [labels](#input\_labels) | Labels for the forwarding rules | `map(string)` | n/a | yes |
| <a name="input_namespace"></a> [namespace](#input\_namespace) | Project namespace | `string` | n/a | yes |
| <a name="input_network"></a> [network](#input\_network) | Network that accommodates the consumer resources. | `string` | n/a | yes |
| <a name="input_project"></a> [project](#input\_project) | Project ID/Name | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | Project region | `string` | n/a | yes |
| <a name="input_response_policy_rules"></a> [response\_policy\_rules](#input\_response\_policy\_rules) | n/a | <pre>list(object({<br>    dns_name              = optional(string)<br>    purpose               = optional(string)<br>    load_balancing_scheme = optional(string)<br>    base_dns              = optional(string)<br>    base_ip               = optional(string)<br>    local_data = object({<br>      name                  = optional(list(string))<br>      type                  = optional(string)<br>      ttl                   = optional(number)<br>      service_attachment_id = optional(list(string))<br>      region                = optional(string)<br>      port_range            = optional(list(number))<br>    })<br>  }))</pre> | n/a | yes |
| <a name="input_routing_mode"></a> [routing\_mode](#input\_routing\_mode) | The network routing mode either global or regional | `string` | n/a | yes |
| <a name="input_subnet_mapping"></a> [subnet\_mapping](#input\_subnet\_mapping) | n/a | `map(string)` | <pre>{<br>  "europe-west3": "cdw-private1-subnet-europe-west3",<br>  "europe-west4": "cdw-helix-networking-to-flyte-subnet-europe-west4"<br>}</pre> | no |
| <a name="input_usecase"></a> [usecase](#input\_usecase) | Project Usecase | `string` | n/a | yes |
| <a name="input_vpc_ids"></a> [vpc\_ids](#input\_vpc\_ids) | n/a | `list(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_dns_info"></a> [dns\_info](#output\_dns\_info) | DNS Info |
| <a name="output_dns_response_policy_info"></a> [dns\_response\_policy\_info](#output\_dns\_response\_policy\_info) | DNS Response Policy Info |
<!-- END_TF_DOCS -->