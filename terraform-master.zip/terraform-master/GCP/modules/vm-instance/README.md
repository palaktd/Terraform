<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google_compute_disk.boot](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_disk) | resource |
| [google_compute_instance.vm](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_instance) | resource |
| [google_compute_zones.available_zones](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/compute_zones) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_allow_stopping_for_update"></a> [allow\_stopping\_for\_update](#input\_allow\_stopping\_for\_update) | Allow Terraform to stop the VM to update | `bool` | `true` | no |
| <a name="input_automatic_restart"></a> [automatic\_restart](#input\_automatic\_restart) | If an instance should be restarted if it was terminated by Compute Engine (not a user). | `bool` | `true` | no |
| <a name="input_boot_disk_auto_delete"></a> [boot\_disk\_auto\_delete](#input\_boot\_disk\_auto\_delete) | Whether to auto delete disk when deleting instance | `bool` | n/a | yes |
| <a name="input_boot_disk_device_name"></a> [boot\_disk\_device\_name](#input\_boot\_disk\_device\_name) | Name with which attached disk will be accessible under /dev/disk/by-id/ | `string` | `"boot"` | no |
| <a name="input_boot_disk_image"></a> [boot\_disk\_image](#input\_boot\_disk\_image) | Boot image name used for compute VMs. | `string` | n/a | yes |
| <a name="input_boot_disk_labels"></a> [boot\_disk\_labels](#input\_boot\_disk\_labels) | Map of label values to pass to boot disk. | `map(any)` | `{}` | no |
| <a name="input_boot_disk_size"></a> [boot\_disk\_size](#input\_boot\_disk\_size) | Size of disk in GB | `number` | n/a | yes |
| <a name="input_boot_disk_type"></a> [boot\_disk\_type](#input\_boot\_disk\_type) | Type of disk | `string` | n/a | yes |
| <a name="input_deletion_protection"></a> [deletion\_protection](#input\_deletion\_protection) | Protect VM from accidental deletion | `bool` | `false` | no |
| <a name="input_description"></a> [description](#input\_description) | Description for the instance. | `string` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | Which environment (dev or prod) | `string` | n/a | yes |
| <a name="input_firewall_tags"></a> [firewall\_tags](#input\_firewall\_tags) | Target tags added to instances for firewall and networking. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_instancename"></a> [instancename](#input\_instancename) | Name of the instance | `string` | n/a | yes |
| <a name="input_labels"></a> [labels](#input\_labels) | Map of label values to pass to instance. | `map(any)` | `{}` | no |
| <a name="input_machine_type"></a> [machine\_type](#input\_machine\_type) | VM Machine Type | `string` | n/a | yes |
| <a name="input_namespace"></a> [namespace](#input\_namespace) | name space | `string` | n/a | yes |
| <a name="input_on_host_maintenance"></a> [on\_host\_maintenance](#input\_on\_host\_maintenance) | Maintenance behavior for the instance. Can be migrate or terminate | `string` | `"migrate"` | no |
| <a name="input_preemptible"></a> [preemptible](#input\_preemptible) | The instance preemptible. | `bool` | `false` | no |
| <a name="input_project"></a> [project](#input\_project) | The project name. | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | Region for cloud resources | `string` | n/a | yes |
| <a name="input_scopes"></a> [scopes](#input\_scopes) | List of scopes for the instance service account. | `list(string)` | <pre>[<br>  "https://www.googleapis.com/auth/cloud-platform"<br>]</pre> | no |
| <a name="input_service_account"></a> [service\_account](#input\_service\_account) | The Service account for the instance. | `string` | n/a | yes |
| <a name="input_source_tags"></a> [source\_tags](#input\_source\_tags) | Source tags added to instances for firewall and networking. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_ssh_keys"></a> [ssh\_keys](#input\_ssh\_keys) | Content of ssh-keys metadata passed to the instance. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_subnetwork"></a> [subnetwork](#input\_subnetwork) | The subnetwork to deploy to | `string` | n/a | yes |
| <a name="input_subnetwork_project"></a> [subnetwork\_project](#input\_subnetwork\_project) | The project the subnetwork belongs to. If not set, var.project is used instead. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags added to instances. | `list(string)` | <pre>[<br>  "dds"<br>]</pre> | no |
| <a name="input_vm_count"></a> [vm\_count](#input\_vm\_count) | How many vm instances to create | `number` | n/a | yes |
| <a name="input_zone"></a> [zone](#input\_zone) | Zone for cloud resources | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_instance_info"></a> [instance\_info](#output\_instance\_info) | compute instance information |
<!-- END_TF_DOCS -->