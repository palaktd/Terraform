# Terraform modules for AWS Cloud

# Context
![Terraform Shared Modules Folder Structure](https://media.git.i.mercedes-benz.com/user/1779/files/54202e60-3fc9-41eb-9b5c-5e538bcd8612)

# Structure
```
└──application(module name or name of the application ex: vpc, network)
│   └──main.tf
│   └──output.tf
│   └──README.md(information about application)
│   └──variables.tf(variables specific to this application)
└──application2
└──application3
```
# Install Git, AWS CLI Version 2, Terraform (v 0.13.2), Terragrunt (v 0.23.40) and few other necessary packages (curl, vim, and unzip)
```
#! /bin/bash
echo "###################################"
echo "Installing curl, git, vim and unzip"
echo "###################################"
apt-get update
apt-get install curl git vim unzip awscli -y
echo "############################################"
echo "Installing AWS CLI, Terraform and Terragrunt"
echo "############################################"
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
./aws/install
curl -L -o terraform.zip https://releases.hashicorp.com/terraform/0.13.6/terraform_0.13.6_linux_386.zip && unzip -o terraform.zip -d /usr/local/bin/
curl -L -o /usr/local/bin/terragrunt https://github.com/gruntwork-io/terragrunt/releases/download/v0.28.12/terragrunt_linux_386 && chmod u+x /usr/local/bin/terragrunt
```
# Run the below commands to confirm the installation once the above script completes.
```
git --version
aws --version
terraform -v
terragrunt -v
``` 

# Configuring the AWS CLI
This section explains how to configure the settings that the AWS CLI uses to interact with AWS. These include your security credentials, the default output format, and the default AWS Region.

Among different methods of configuring these settings is the environment variables method, which can be useful for scripting or temporarily setting a named profile (IAM User) as the default.

We are using the environment variables method in this tutorial. The following examples show how you can configure environment variables for the default user.

```
export AWS_ACCESS_KEY_ID=YOURIAMUSERACCESSKEY
export AWS_SECRET_ACCESS_KEY=YOURIAMUSERSECRETaBcDxYzEXAMPLEACCESSKEY
export AWS_DEFAULT_REGION=eu-central-1
```
Setting the environment variable changes the value used until the end of your session, or until you set the variable to a different value.

# To execute Terraform modules
```
git clone git@git.daimler.com:GSEP4/terraform.git
```

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

No modules.

## Resources

No resources.

## Inputs

No inputs.

## Outputs

No outputs.
<!-- END_TF_DOCS -->