## Input Variables

| Name | Description |
|------|-------------|
| vpc_id | VPC ID |
| subnet_id | Subnet Id in string |
| ssh_key_pair | SSH key pair |
| vpc_security_group | Security group to attach to an instance |
| private_key | private key and path |