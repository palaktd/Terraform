Connect any ec2 server 
# Install of aws cli on any one of ec2 instalces(Ubuntu)
        sudo apt-get install awscli
# Steps for Adding aws credentials
        aws configure
# Clone of repo
        git clone <repository url>

# Update the 2 json files
        As mentioned in command we need two json files that need to be update
        1. budget.json
        2. notifications-with-subscribers.json

# CLI commands to create a budget for billing alarm
        aws budgets create-budget --account-id youraccountid --budget file://budget.json --notifications-with-subscribers file://notifications-with-subscribers.json
