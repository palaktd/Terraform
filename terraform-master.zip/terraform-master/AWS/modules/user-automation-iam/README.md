## Input Variables

Note: Currently you can add multiple users to single group only. A single user cannot have multiple groups associated by using this code.

| Name | Description | Required |
|------|-------------|----------|
| user_name | user names(list of string one or more) | Yes |
| groups | group name(only one group at a time) | Yes |
| password | default password for user | Yes |
