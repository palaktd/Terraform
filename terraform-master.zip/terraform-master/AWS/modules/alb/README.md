## Input Variables

| Name | Description |
|------|-------------|
| vpc_id | VPC ID |
| subnet_ids | Subnet Ids in string[minimum 2 public subnets] |
