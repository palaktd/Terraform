##
To use this module these are the input variables required
##
# Input variables

  * region                                 = AWS  region
  * name                                   = Name of the bucket
  * bucket_count                           = Number of buckets count
  * lifecycle_rule_enabled                 = A boolean for enabling lifecycle rule for S3
  * noncurrent_version_expiration_days     = Number of days to retain i.e retention days
  * policy                                 = A valid policy in json format