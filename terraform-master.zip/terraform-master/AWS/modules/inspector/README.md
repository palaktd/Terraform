##
To use this module these are the input variables required
##
# Input variables

  * region                      = AWS region
  * assessment_duration         = How long the assessment runs in seconds
  * rules_package_arns          = Amazon Inspector Region-Specific ARNs for rules packages
  * schedule_expression         = How often to run an Inspector assessment
  * iam_role_arn                = The Amazon Resource Name (ARN) of the IAM role to be used
                                  for this target when the rule is triggered
  * event_rule_description      = A description of the CloudWatch event rule