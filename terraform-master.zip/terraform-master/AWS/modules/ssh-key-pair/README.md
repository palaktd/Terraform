## Context
This module helps generating ssh-key-pair to access ec2 instances or you can import your public key to allowing access to ec2 instances.


## Variables

| Name | Description | Required |
|------|-------------|----------|
| generate_ssh_key | true or fase | Yes |
| ssh_public_key_path | path name where your public key is | Yes if generate_ssh_key=false |
| ssh_public_key_file | your local ssh key file name | Yes |
| ssh_key_pair_path | some local path | Yes if generate_ssh_key=true |
