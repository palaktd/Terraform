#### To build customised AMI
```
$terraform apply
```