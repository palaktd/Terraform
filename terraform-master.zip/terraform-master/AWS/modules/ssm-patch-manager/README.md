*** Terraform-aws-automated-ssm-patch-manager****

    └──aws-automated-ssm-patch-manager(moduleName-ssm-patch-manager)
    
    └──ssm-automation-execution-aws-documents.tf
    
    └──ssm-maintenance-window-task-targets.tf
    
    └──ssm-patch-baseline.tf
    
    └──ssm-patching-instance-assume-role-policy-attachment.tf
    
    └──ssm-resource-groups.tf
    
    └──output.tf
    
    └──README.md(information about ssm patch manage)
    
    └──variables.tf(variables specific to this ssm patch manager)


**Managed Services **- ssm-patch-manager automation using Terraform scripts-Software Security and OS Patches updating using Terraform.

This terraform scripts will  supports the Operating security patching with AWS Systems Manager

**Prerequisites:**

In order to run this template you will need an user with the permission to the following services: • Iam-role
 ###Custom SSMPatchServer-patch module 
    • Iam-policy
    • ssm -Installing SSM Agent on EC2
    • ec2
    • Resource Groups
    • Patch Manager
    • Patch Baselines
    • Maintenance Windows scheduled

**Go to the terraform folder and initialize**

$ terraform init

    This will download all terraform prerequisites modules 
    
    cd terraform
    
    terraform init you should see the following output
    
    terraform has been successfully initialized!

**Run a plan**

$ Terrafrom plan

  terraform plan is a dry run that simulates the execution
  terraform plan After selecting the region it should output
  that means you are ready to apply the plan

**Run a terrafomr apply**

$ terraform apply --auto-approve

  Apply complete! Resources: 19 added, 0 changed, 0 destroyed
