# To execute terraform module

Note: Subnet module is dependent on VPC module hence executing from subnets folder will create and associate vpc and subnets both.
```
$git clone git clone git@git.daimler.com:GSEP4/terraform.git
$cd network/subnets
$terraform apply #This will create vpc and subnets and associate both.
```