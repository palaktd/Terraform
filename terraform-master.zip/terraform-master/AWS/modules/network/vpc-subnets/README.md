## Input Variables

| Name | Description |
|------|-------------|
| availability_zones | names of azs |
| cidr_block | 10.0.0.0/16 |
| private_subnet_cidr_block | CIDR range for each subnet |
| public_subnet_cidr_block | CIDR range for each subnet |
