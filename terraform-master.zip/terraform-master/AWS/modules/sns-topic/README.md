##
To use this module these are the input variables required
##
# Input variables

  * region                                 = AWS region
  * kms_master_key_id                      = The ID of an AWS-managed customer master key 
                                             (CMK) for Amazon SNS or a custom CMK
  * delivery_policy                        = JSON String with the delivery policy 
                                            (retries, backoff, etc.) that will be used in the subscription
  * endpoint                               = Endpoint to send data to.
                                             The contents vary with the protocol.