 #
# Create Lambda functions to start your EC2 instances.
#
     
import json
import boto3
region = 'eu-central-1'
def start(event, lambda_context):
    ec2_client = boto3.client("ec2", region_name=region)
    reservations = ec2_client.describe_instances(Filters=[
        {
            "Name": 'tag:AutomaticOn',
            "Values": ['True'],
        }
    ]).get("Reservations")

    for reservation in reservations:
        for instance in reservation["Instances"]:
            instance_id = instance["InstanceId"]
            ec2_client.start_instances(InstanceIds=[instance_id])
            print(f"Instances Started " + str(instance_id))
