## Variables

| Name | Description |
|------|-------------|
| CloudWatch Event Rule | StopEC2Instances | StartEC2Instances |
| aws_iam_Policy| StopStartEC2Policy |
| aws_iam_Role| StopStartEC2Role |
| Lambda_Function_Name  | AutoStopStartEC2Instance |
