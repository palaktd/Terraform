#
# #Create Lambda functions to stop your EC2 instances.
#

import json
import boto3
region = 'eu-central-1'
def stop(event, lambda_context):
    ec2_client = boto3.client("ec2", region_name=region)
    reservations = ec2_client.describe_instances(Filters=[
        {
            "Name": 'tag:AutomaticOff',
            "Values": ['True'],
        }
    ]).get("Reservations")

    for reservation in reservations:
        for instance in reservation["Instances"]:
            instance_id = instance["InstanceId"]
            ec2_client.stop_instances(InstanceIds=[instance_id])
            print(f"Instances Stopped " + str(instance_id))
