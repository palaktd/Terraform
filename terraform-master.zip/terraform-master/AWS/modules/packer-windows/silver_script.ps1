Write-Host "running powershell script"

# Turn off Windows Defender Firewall
netsh advfirewall set allprofiles state off
Write-Host "Turned off Windows Defender Firewall"

pwd

# Golden Image
Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
#==================================================Start=============
choco install openssh -y
# Openssh through choco
. "C:\Program Files\OpenSSH-Win64\install-sshd.ps1"
#. "C:\Program Files\OpenSSH-Win64\ssh-keygen.exe" -A
#yes '' | ssh-keygen -N ''
#ssh-keygen -b 2048 -t rsa -q -N '""'
refreshenv
cd 'C:\Program Files\OpenSSH-Win64'
.\FixHostFilePermissions.ps1 -Confirm:$False
cd 'C:\Users\Administrator'
pwd
Start-Service sshd
Set-Service SSHD -StartupType Automatic
Set-Service SSH-Agent -StartupType Automatic
New-ItemProperty -Path 'HKLM:\SOFTWARE\OpenSSH' -Name DefaultShell -Value 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -PropertyType String -Force
Write-Host "openssh service successfully installed via Packer"
#==================================================END=============
choco install notepadplusplus -y
choco install telnet -y
choco install git.install -y
choco install openjdk11jre -y
choco install 7zip.install -y
choco install googlechrome -y
choco install awscli -y
#  commands for avoid 'aws is not recognised as an internal commands'
$command = '[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12'
Invoke-Expression $command
Invoke-WebRequest -Uri 'https://awscli.amazonaws.com/AWSCLIV2.msi' -Outfile C:\AWSCLIV2.msi
$arguments = '/i `"C:\AWSCLIV2.msi`" /quiet'
Start-Process msiexec.exe -ArgumentList $arguments -Wait
$env:Path = [System.Environment]::GetEnvironmentVariable('Path','Machine')

refreshenv

#configure aws cli
Set-AWSCredentials -AccessKey 'accesskey' -SecretKey 'secretkey' -StoreAs MyMainUserProfile
Initialize-AWSDefaults -ProfileName MyMainUserProfile -Region regionname
$Creds = (Use-STSRole -RoleArn 'arn number' -RoleSessionName 'MyRoleSessionName').Credentials
Write-Host "installed Aws Cli and set env"
#get-iamroles -Credential $Creds

refreshenv
aws --version
aws s3 ls

#===========================SSH Connection===============
#Coping web content and placed in a text file(not required)
$Response = Invoke-WebRequest -URI "http://169.254.169.254/latest/meta-data/public-keys/0/openssh-key"  -OutFile "key2.txt"

# pem file should be in "idrsa"
aws s3 cp s3://bucketname/pemkey "C:\Users\Administrator\.ssh\id_rsa"

# outfile web content should be in "idrsa_pub"
aws s3 cp s3://bucketname/publickey "C:\Users\Administrator\.ssh\id_rsa.pub"
#$Response = Invoke-WebRequest -URI "http://169.254.169.254/latest/meta-data/public-keys/0/openssh-key"  -OutFile "C:\Users\Administrator\.ssh\id_rsa.pub"

# outfile web content should be in "administrators_authorized_keys"
aws s3 cp s3://bucketname/publickey "C:\Users\Administrator\.ssh\administrators_authorized_keys"

# created "administrators_authorized_keys" file and kept web content(public key ending with keypair)
$Response = Invoke-WebRequest -URI "http://169.254.169.254/latest/meta-data/public-keys/0/openssh-key"  -OutFile "C:\Users\Administrator\.ssh\administrators_authorized_keys"
# create "known_hosts" file in .ssh
New-Item -Path "C:\Users\Administrator\.ssh\known_hosts"

# added "id_rsa" and "id_rsa.pub" files into "C:/default/.ssh" folder
# pem file should be in "idrsa"
aws s3 cp s3://bucketname/pemkey "C:\Users\Default\.ssh\id_rsa"

# outfile web content should be in "idrsa_pub"
aws s3 cp s3://bucketname/publickey "C:\Users\Default\.ssh\id_rsa.pub"
#$Response = Invoke-WebRequest -URI "http://169.254.169.254/latest/meta-data/public-keys/0/openssh-key"  -OutFile "C:\Users\Default\.ssh\id_rsa.pub"

# created adminstrator_authorisedkeys file in C:/programData/ssh
aws s3 cp s3://bucketname/publickey "C:\ProgramData\ssh\administrators_authorized_keys"
#$Response = Invoke-WebRequest -URI "http://169.254.169.254/latest/meta-data/public-keys/0/openssh-key"  -OutFile "C:\ProgramData\ssh\administrators_authorized_keys"

Write-Host "files successfully saved in respective path"
# Run below commands in
$acl = Get-Acl C:\ProgramData\ssh\administrators_authorized_keys
$acl.SetAccessRuleProtection($true, $false)
$administratorsRule = New-Object system.security.accesscontrol.filesystemaccessrule("Administrators","FullControl","Allow")
$systemRule = New-Object system.security.accesscontrol.filesystemaccessrule("SYSTEM","FullControl","Allow")
$acl.SetAccessRule($administratorsRule)
$acl.SetAccessRule($systemRule)
$acl | Set-Acl
#######################################Silver Set up#######################################
# Download Silver from s3
aws s3 cp s3://S3bucketname/excutalefileins3 C:\s3-downloads\
# Silver env set up
[System.Environment]::SetEnvironmentVariable('SNPSLMD_LICENSE_FILE','port@IPAdress')
# Install Silver
Start-Process -Wait -FilePath C:/s3-downloads/excutalefileins3 -ArgumentList '/VERYSILENT /FORCECLOSEAPPLICATIONS /SUPPRESSMSGBOXES /SP /DONOTINSTALLCMSERVICE'
[Environment]::SetEnvironmentVariable
      ("Path", $env:Path, [System.EnvironmentVariableTarget]::Machine)
######################################################