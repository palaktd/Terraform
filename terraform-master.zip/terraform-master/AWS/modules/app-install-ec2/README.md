## Input Variables

| Name | Description | Required |
|------|-------------|----------|
| ansible_user | ansible user to run playbooks | yes |
| private_key | to access ec2 instance | yes |
| git_repo_url | where your ansible jenkins playbook is stored | yes |
| git_username | to clone git repo | yes |
| git_token_key | access token key | yes |