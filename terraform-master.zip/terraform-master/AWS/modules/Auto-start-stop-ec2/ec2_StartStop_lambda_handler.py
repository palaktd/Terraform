#########*********************************************************************************#########
######### Title        : DVAS Production IND/DE Bastian servers Auto-start/stop service   #########
#########*********************************************************************************#########
######### Description  : Create Lambda functions to start/stop EC2 instances based on IST #########
#########                and UCT time zones for cost optimization.                        #########
#########*********************************************************************************#########
######### Created on   : 06-Apr-2023                                                      #########
#########*********************************************************************************#########-
######### Modified on  : 06-Apr-2023                                                      #########
#########*********************************************************************************#########
######### Authors      : Hanumesh Jitta |                                                 #########
#########*********************************************************************************#########
    

#***************************Importing necessary packages******************************************#
import json
import boto3
import botocore
#***************************Declaring Global Variables********************************************#

region = 'eu-central-1'

#************Start Function validates the curent event and triggers the instance action***********#

def start(event, lambda_context):
    ec2_client = boto3.client("ec2", region_name=region)

#**********************Initializing the loacal variables******************************************#

    reservations = []
    flag_start = False
    flag_stop = False

#************************Trying to validate the current even name*********************************#
    
    try:
        
        if "India-Time-DvaS-Auto-Start-Bastian-EC2Instances" in str(event['resources']):
            curr_tag_name = 'tag:AutomaticOn'
            flag_start = True
        elif "India-Time-DvaS-Auto-Stop-Bastian-EC2Instances" in str(event['resources']):
            curr_tag_name = 'tag:AutomaticOff'
            flag_stop = True
        elif "Germany-Time-DvaS-Auto-Start-Bastian-EC2Instances" in str(event['resources']):
            curr_tag_name = 'tag:DEAutomaticOn'
            flag_start = True
        elif "Germany-Time-DvaS-Auto-Stop-Bastian-EC2Instances" in str(event['resources']):
            curr_tag_name = 'tag:DEAutomaticOff'
            flag_stop = True
            
#*********************Collecting reservations to loop through all the instances*******************#
    
        reservations = ec2_client.describe_instances(Filters=[
            {
                "Name": curr_tag_name,
                "Values": ['True']
            }
        ]).get("Reservations")
        print(f"Reservations: {reservations}")
        
        
#********************Looping through all the instances to action Start/Stop**************#
        
        for reservation in reservations:
            for instance in reservation["Instances"]:
                instance_id = instance["InstanceId"]
                if flag_start:
                    ec2_client.start_instances(InstanceIds=[instance_id])
                    print(f"Instances Started " + str(instance_id))
                elif flag_stop:
                    ec2_client.stop_instances(InstanceIds=[instance_id])
                    print(f"Instances Stopped " + str(instance_id))
                    
#*********Handling exception in case of any client error with Botocore********#
    
    except botocore.exceptions.ClientError as error:
        raise ValueError('ERROR : unable to action the instance{}'.format(instance_id))
