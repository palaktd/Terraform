## Variables

| Name                               | Description |
|------|-------------------------------------------|
| CloudWatch Event RuleNames: | India_TimeZone_dvs_ec2_stop-instances   |
                              | India_TimeZone_dvs_ec2_start_instances  |
                              | Germany_TimeZone_dvs_ec2_start_instances|
                              | Germany_TimeZone_dvs_ec2_stop_instances |

| aws_iam_Policy               | StopStartEC2Policy |
| aws_iam_Role                 | StopStartEC2Role |
| Lambda_Function_Name         | IND-DE-TimeZones-DvaS-Prod-Bastian-servers-AutoStopStartEC2Instance |
